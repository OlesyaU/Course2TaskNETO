//
//  DataProvider.h
//  DataProvider
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DataProvider.
FOUNDATION_EXPORT double DataProviderVersionNumber;

//! Project version string for DataProvider.
FOUNDATION_EXPORT const unsigned char DataProviderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DataProvider/PublicHeader.h>


