//
//  HeaderFeedCell.swift
//  Course2FinalTask
//
//  Created by Олеся on 05.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit
import DataProvider

final class FeedHeader: UIView {
    
    var post: Post? {
        didSet {
            avatarImageView.image = post?.authorAvatar
            nameLabel.text = post?.authorUsername
            dateLabel.text = makeFormattedDate(post: post)
        }
    }
    
    let ident = "FeedHeader"
    
    private let avatarImageView: UIImageView = {
        let imageView = UIImageView(frame: .zero)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private let nameLabel: UILabel = {
        let nameLabel = UILabel(frame: .zero)
        nameLabel.font = .systemFont(ofSize: 14, weight: .semibold)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.textColor = .black
        return nameLabel
    }()
    
    private let dateLabel: UILabel = {
        let dateLabel = UILabel()
        dateLabel.font = .systemFont(ofSize: 14)
        dateLabel.textColor = .black
        dateLabel.translatesAutoresizingMaskIntoConstraints = false
        return dateLabel
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubviewsToHeader()
        avatarConstraints()
        nameConstraints()
        dateConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    private func makeFormattedDate(post: Post?) -> String? {
        guard let post = post else { return nil }
        
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        formatter.dateStyle = .medium
        formatter.doesRelativeDateFormatting = true
        
        return formatter.string(from: post.createdTime)
    }
    
    private func addSubviewsToHeader() {
        addSubview(avatarImageView)
        addSubview(nameLabel)
        addSubview(dateLabel)
    }
    
    private func avatarConstraints(){
        avatarImageView.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 15).isActive = true
        avatarImageView.topAnchor.constraint(equalTo: self.topAnchor, constant: 8).isActive = true
        avatarImageView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -8).isActive = true
        avatarImageView.heightAnchor.constraint(equalToConstant: 35.0).isActive = true
        avatarImageView.widthAnchor.constraint(equalTo: avatarImageView.heightAnchor).isActive = true
    }
    
    private func nameConstraints() {
        nameLabel.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 8).isActive = true
        nameLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        nameLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 8).isActive = true
    }
    
    private func dateConstraints() {
        dateLabel.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 8).isActive = true
        dateLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -8).isActive = true
        dateLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
    }
}


