//
//  FeedViewController.swift
//  Course2FinalTask
//
//  Created by Олеся on 11.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit
import DataProvider

final class FeedViewController: UICollectionViewController {
    
    private var viewModel: FeedViewModel
    
    private var layout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width + 145)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        return layout
    }()
    
    init(model: FeedViewModel) {
        self.viewModel = model
        super.init(collectionViewLayout: layout)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViewModel()
        setupInitialState()
    }
    
    // MARK: - UICollectionViewDataSource
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.posts.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: FeedCell.self),for: indexPath) as? FeedCell
            else {
                return UICollectionViewCell()
        }
        
        cell.post = viewModel.posts[indexPath.item]
        cell.delegate = viewModel
        
        return cell
    }
    
    private func setupViewModel() {  
        viewModel.onProfileTapped = { [unowned self] profileViewModel in
            let profileController = ProfController(model: profileViewModel)
            self.navigationController?.pushViewController(profileController, animated: true)
        }
        
        viewModel.onLikesLabelTapped = { [unowned self] profileViewModels in
            let followersViewController = FOLTableViewController(viewModels: profileViewModels, type: .likes)
            self.navigationController?.pushViewController(followersViewController, animated: true)
        }
        
        viewModel.onReloadCell = { [unowned self] cell in
            guard let indexPath = self.collectionView.indexPath(for: cell) else { return }
            
            DispatchQueue.main.async {
                self.collectionView.reloadItems(at: [indexPath])
            }
        }
    }
    
    func setupInitialState() {
        title = self.viewModel.navBarTitle
        collectionView?.register(FeedCell.self, forCellWithReuseIdentifier: String(describing: FeedCell.self))
        collectionView.backgroundColor = self.viewModel.backgroundColor
        collectionView.setCollectionViewLayout(self.layout, animated: true)
    }
}
