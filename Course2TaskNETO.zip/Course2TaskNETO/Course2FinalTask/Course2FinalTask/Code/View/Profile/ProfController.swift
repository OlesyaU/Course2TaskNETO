//
//  ProfController.swift
//  Course2FinalTask
//
//  Created by Олеся on 23.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit

class ProfController: UICollectionViewController {
    
    enum ListType {
        case followers
        case following
        case likes
        
        var title: String {
            switch self {
            case .likes: return "Likes"
            case .following: return "Following"
            case .followers: return "Followers"
            }
        }
    }
    
    private let reuseIdentifier = "Cell"
    private let reuseIDHeader = "Header"
    private var viewModel: ProfileViewModel
    private let itemsPerRow: CGFloat = 3
    private let sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
    
    init(model: ProfileViewModel) {
        self.viewModel = model
        super.init(collectionViewLayout: UICollectionViewFlowLayout())
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.backgroundColor = .white
        collectionView?.register(ProfileCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        collectionView.register( ProfileHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: reuseIDHeader)
        title = viewModel.user.fullName
        navigationController?.title = "Profile"
    }
    
    // MARK: UICollectionViewDataSource
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.currentUserPosts.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as? ProfileCell else {return UICollectionViewCell()}
        cell.postImage.image = viewModel.currentUserPosts[indexPath.item].image
        return cell
    }
    
    
    override func collectionView(_ collectionView: UICollectionView,
                                 viewForSupplementaryElementOfKind kind: String,
                                 at indexPath: IndexPath) -> UICollectionReusableView {
        
        guard let headerView = collectionView.dequeueReusableSupplementaryView(
            ofKind: UICollectionView.elementKindSectionHeader,
            withReuseIdentifier: reuseIDHeader, for: indexPath) as? ProfileHeader
            else { return UICollectionReusableView() }
        
        headerView.viewModel = viewModel
        
        headerView.onShowFollowing = { [unowned self] in
            self.showUserList(type: .following)
        }
        
        headerView.onShowFollowers = { [unowned self] in
            self.showUserList(type: .followers)
        }
        
        return headerView
        
    }
    
    private func showUserList(type: ListType) {
        var profileViewModels: [ProfileViewModel] = []
        
        switch type {
        case .followers:
            profileViewModels = viewModel.followers.map { ProfileViewModel(user: $0) }
        case .following:
            profileViewModels = viewModel.follows.map { ProfileViewModel(user: $0) }
        default:
            break
        }
        
        guard !profileViewModels.isEmpty else { return }
        
        let profileViewController = FOLTableViewController(viewModels: profileViewModels, type: type)
        navigationController?.pushViewController(profileViewController, animated: true)
    }
}

extension ProfController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInset.right
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInset.bottom
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInset
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let padding =  sectionInset.left * (itemsPerRow + 1)
        let widthGenerally = collectionView.frame.width - padding
        let itemWidth = widthGenerally / itemsPerRow
        return CGSize(width: itemWidth, height: itemWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize( width: self.view.frame.width, height: 86)
    }
    
}
