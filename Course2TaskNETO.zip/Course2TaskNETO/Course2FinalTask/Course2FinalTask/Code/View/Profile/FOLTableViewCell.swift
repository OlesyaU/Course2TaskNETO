//
//  FOLTableViewCell.swift
//  Course2FinalTask
//
//  Created by Олеся on 28.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit

final class FOLTableViewCell: UITableViewCell {
    
    var viewModel: ProfileViewModel? {
        didSet {
            avatarImageView.image = viewModel?.user.avatar
            nameLabel.text = viewModel?.user.fullName
        }
    }
    
    private let avatarImageView: UIImageView = {
        let avatar = UIImageView()
        avatar.contentMode = .scaleAspectFit
        avatar.translatesAutoresizingMaskIntoConstraints = false
        return avatar
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = .systemFont(ofSize: 17)
        label.sizeToFit()
        label.numberOfLines = 0
        label.minimumScaleFactor = 10
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let dividerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.groupTableViewBackground
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        addSubviews()
        setupConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func addSubviews() {
        contentView.addSubview(avatarImageView)
        contentView.addSubview(dividerView)
        contentView.addSubview(nameLabel)
    }
    
    private func setupConstraints() {
        let constraints = [
            avatarImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            avatarImageView.heightAnchor.constraint(equalToConstant: 44),
            avatarImageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            avatarImageView.widthAnchor.constraint(equalToConstant: 44),
            
            dividerView.topAnchor.constraint(equalTo: avatarImageView.bottomAnchor),
            dividerView.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 16),
            dividerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            dividerView.heightAnchor.constraint(equalToConstant: 1),
            dividerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            
            nameLabel.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 16),
            nameLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor)
        ]
        
        NSLayoutConstraint.activate(constraints)
    }
    
}
