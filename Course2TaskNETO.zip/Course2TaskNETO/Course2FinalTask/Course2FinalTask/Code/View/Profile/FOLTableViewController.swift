//
//  FOLTableViewController.swift
//  Course2FinalTask
//
//  Created by Олеся on 28.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit


class FOLTableViewController: UITableViewController {
    
    typealias ListType = ProfController.ListType
    
    private var viewModels: [ProfileViewModel]
    
    init(viewModels: [ProfileViewModel], type: ListType) {
        self.viewModels = viewModels
        super.init(style: .plain)
        
        title = type.title
        tableView.separatorStyle = .none
        tableView.register(FOLTableViewCell.self, forCellReuseIdentifier: String(describing: FOLTableViewCell.self))
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModels.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: FOLTableViewCell.self), for: indexPath) as? FOLTableViewCell else {return UITableViewCell()}
        
        cell.viewModel = viewModels[indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let profileViewController = ProfController(model: viewModels[indexPath.row])
        navigationController?.pushViewController(profileViewController, animated: true)
    }
}
