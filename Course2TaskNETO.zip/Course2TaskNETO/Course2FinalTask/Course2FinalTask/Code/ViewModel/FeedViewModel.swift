//
//  FeedViewModel.swift
//  Course2FinalTask
//
//  Created by Олеся on 06.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import Foundation
import DataProvider

final class FeedViewModel: NSObject {
    
    var onProfileTapped: ((ProfileViewModel) -> Void)?
    var onLikesLabelTapped: (([ProfileViewModel]) -> Void)?
    var onReloadCell: ((FeedCell) -> Void)?
    
    enum Event {
        case postImageDoubleTapped(cell: FeedCell)
        case postHeaderTapped(cell: FeedCell)
        case likeTapped(cell: FeedCell)
        case likesLabelTapped(cell: FeedCell)
    }
    
    let navBarTitle = "Feed"
    let backgroundColor: UIColor = .white
    
    var posts: [Post] {
        return DataProviders.shared.postsDataProvider.feed()
    }
    
    func runEvent(_ event: Event) {
        switch event {
        case .postImageDoubleTapped(let cell):
            guard let post = cell.post else { return }
            _ = DataProviders.shared.postsDataProvider.likePost(with: post.id)
            onReloadCell?(cell)
            
        case .postHeaderTapped(let cell):
            guard
                let post = cell.post,
                let user = DataProviders.shared.usersDataProvider.user(with: post.author)
                else { return }
            
            let profileViewModel = ProfileViewModel(user: user)
            
            onProfileTapped?(profileViewModel)
            
        case .likeTapped(let cell):
            guard let post = cell.post else { return }
            
            if post.currentUserLikesThisPost {
                _ = DataProviders.shared.postsDataProvider.unlikePost(with: post.id)
            } else {
                _ = DataProviders.shared.postsDataProvider.likePost(with: post.id)
            }
            
            onReloadCell?(cell)
            
        case .likesLabelTapped(let cell):
            guard let post = cell.post else { return }
            
            let viewModels = DataProviders.shared.postsDataProvider.usersLikedPost(with: post.id)?
                .compactMap { DataProviders.shared.usersDataProvider.user(with: $0) }
                .compactMap { ProfileViewModel(user: $0) }
            
            guard
                let profileViewModels = viewModels,
                !profileViewModels.isEmpty
                else { return }
            
            onLikesLabelTapped?(profileViewModels)
        }
    }
}
// MARK: - FeedCellDelegate
extension FeedViewModel: FeedCellDelegate {
    func likesLabelTapped(cell: FeedCell) {
        runEvent(.likesLabelTapped(cell: cell))
    }
    
    func postHeaderTapped(cell: FeedCell) {
        runEvent(.postHeaderTapped(cell: cell))
    }
    
    func postImageDoubleTapped(cell: FeedCell) {
        runEvent(.postImageDoubleTapped(cell: cell))
    }
    
    func likeTapped(cell: FeedCell) {
        runEvent(.likeTapped(cell: cell))
    }
}
