//
//  ProfileViewModel.swift
//  Course2FinalTask
//
//  Created by Олеся on 13.07.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import Foundation
import DataProvider

final class ProfileViewModel {
    
    let user: User
    
    init(user: User) {
        self.user = user
    }
    
    var currentUserPosts: [Post] {
        return DataProviders.shared.postsDataProvider.findPosts(by: user.id) ?? []
    }
    
    var followers: [User] {
        return DataProviders.shared.usersDataProvider.usersFollowingUser(with: user.id) ?? []
    }
    
    var follows: [User] {
        return DataProviders.shared.usersDataProvider.usersFollowedByUser(with: user.id) ?? []
    }
}
